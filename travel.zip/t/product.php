<?php

include ('header.php');
?>

<?php

    include ('Template/_alltour.php');

 

?>

<?php
include ('footer.php');
?>

