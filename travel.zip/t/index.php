
<?php
ob_start();

include('header.php');
?>


<?php


include('Template/_banner-area.php');

include('Template/_special-event.php');

include('Template/_top-visite.php');


include('Template/_new-event.php');



?>


<?php

include('footer.php');
?>