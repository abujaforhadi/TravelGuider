<?php
    ob_start();
    // include header.php file
    include ('header.php');
?>

<?php
    
    include ('Template/_special-event.php');
?>
<?php
// include footer.php file
include ('footer.php');
?>