<?php
    ob_start();
    // include header.php file
    include ('header.php');
?>

<?php
    
    include ('Template/_demo.php');
?>
<?php
// include footer.php file
include ('footer.php');
?>